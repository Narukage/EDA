//DNI 48620792B BARBA ROBLES, ALBERTO
public class CiudadNoEncontradaExcepcion extends Exception{	
	public CiudadNoEncontradaExcepcion(String a){
		super(a);
	}
}
