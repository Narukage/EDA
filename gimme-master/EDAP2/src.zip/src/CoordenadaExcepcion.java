//DNI 48620792B BARBA ROBLES, ALBERTO

public class CoordenadaExcepcion extends Exception{

		public CoordenadaExcepcion(String a){
			super(a);
		}
		
}
